import { useState, useEffect } from "react";
import Head from "next/head";
import Layout from "../components/Layout";
import { useSession, useSupabaseClient } from "@supabase/auth-helpers-react";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import interactionPlugin from "@fullcalendar/interaction";
import { DateSelectArg, DayCellContentArg } from "@fullcalendar/core";
import { ClipboardList, Droplet, CalendarPlus } from "lucide-react";

type SQLEvent = { id: string; title: string; start_ts: string; end_ts: string };
type HabitRow = {
  date: string;
  pills: boolean;
  bath: boolean;
  workout: boolean;
  friends: boolean;
  work: boolean;
  housework: boolean;
  plants: boolean;
  duolingo: boolean;
};
type WaterRow = { date: string; amount: number };

export default function CalendarPage() {
  const session = useSession();
  const supabase = useSupabaseClient();
  const token = session?.provider_token;
  const userEmail = session?.user?.email!;

  const [sqlEvents, setSqlEvents] = useState<SQLEvent[]>([]);
  const [habitsMap, setHabitsMap] = useState<Record<string, number>>({});
  const [waterMap, setWaterMap] = useState<Record<string, number>>({});
  const [tasksMap, setTasksMap] = useState<Record<string, number>>({});
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [newTitle, setNewTitle] = useState("");

  // fetch all data once
  useEffect(() => {
    if (!session) return;

    // 1) SQL events
    supabase
      .from("events")
      .select("*")
      .eq("user", userEmail)
      .then(({ data }) => data && setSqlEvents(data));

    // 2) habits
    supabase
      .from("daily_habits")
      .select("*")
      .eq("user", userEmail)
      .then(({ data }) => {
        if (data) {
          const m: Record<string, number> = {};
          data.forEach((r) => {
            const count = [
              r.pills,
              r.bath,
              r.workout,
              r.friends,
              r.work,
              r.housework,
              r.plants,
              r.duolingo,
            ].filter(Boolean).length;
            m[r.date] = count;
          });
          setHabitsMap(m);
        }
      });

    // 3) water
    supabase
      .from("water_tracker")
      .select("*")
      .eq("user", userEmail)
      .then(({ data }) => {
        if (data) {
          const m: Record<string, number> = {};
          data.forEach((r) => (m[r.date] = r.amount));
          setWaterMap(m);
        }
      });

    // 4) tasks count
    supabase
      .rpc("count_tasks_by_date", {}) // assumes you created an RPC that returns {date, count}
      .then(({ data }) => {
        if (data) {
          const m: Record<string, number> = {};
          (data as any[]).forEach((r) => (m[r.date] = r.count));
          setTasksMap(m);
        }
      });
  }, [session]);

  // on day‐click: open add-form
  const handleDateSelect = (selectInfo: DateSelectArg) => {
    setSelectedDate(selectInfo.startStr);
    setNewTitle("");
  };

  // create both in SQL and Google
  const handleAddEvent = async () => {
    if (!selectedDate || !newTitle) return;

    // 1) SQL
    await supabase
      .from("events")
      .insert({ user: userEmail, title: newTitle, start_ts: selectedDate });

    // 2) Google
    await fetch(
      `https://www.googleapis.com/calendar/v3/calendars/primary/events`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          summary: newTitle,
          start: { date: selectedDate },
          end: { date: selectedDate },
        }),
      }
    );

    // refresh
    const { data } = await supabase
      .from("events")
      .select("*")
      .eq("user", userEmail);
    data && setSqlEvents(data);
  };

  // inject custom cell content
  const renderDayCell = (arg: DayCellContentArg, defaultContent: any) => {
    const date = arg.dateStr;
    const dots = habitsMap[date] || 0;
    return (
      <div>
        <div>{arg.dayNumberText}</div>
        <div className="flex">
          {Array.from({ length: dots }).map((_, i) => (
            <span
              key={i}
              className="w-1 h-1 bg-green-500 rounded-full mx-[1px]"
            />
          ))}
        </div>
        <div className="flex items-center text-xs">
          <ClipboardList className="w-3 h-3 mr-1" />
          {tasksMap[date] || 0}
        </div>
        <div className="flex items-center text-xs">
          <Droplet className="w-3 h-3 mr-1" />
          {(waterMap[date] || 0).toFixed(1)}L
        </div>
      </div>
    );
  };

  return (
    <>
      <Head>
        <title>Kalendarz – Dzisiaj v3</title>
      </Head>
      <Layout>
        {!session ? (
          <p className="text-center">Zaloguj, aby zobaczyć kalendarz.</p>
        ) : (
          <>
            <div className="mb-4 flex justify-end">
              <CalendarPlus className="w-6 h-6 mr-2" />
              <span>Wybierz dzień, aby dodać wydarzenie</span>
            </div>

            <FullCalendar
              plugins={[dayGridPlugin, interactionPlugin]}
              initialView="dayGridMonth"
              selectable
              select={handleDateSelect}
              dayCellContent={renderDayCell}
              events={sqlEvents.map((e) => ({
                id: e.id,
                title: e.title,
                start: e.start_ts,
                end: e.end_ts,
              }))}
              height="auto"
            />

            {selectedDate && (
              <div className="mt-6 p-4 bg-card rounded-xl shadow">
                <h3 className="font-semibold mb-2">
                  Dodaj wydarzenie – {selectedDate}
                </h3>
                <input
                  type="text"
                  placeholder="Tytuł"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full p-2 border rounded mb-2"
                />
                <button
                  onClick={handleAddEvent}
                  className="px-4 py-2 bg-primary text-white rounded"
                >
                  Dodaj
                </button>

                <h4 className="mt-4 font-medium">Szczegóły:</h4>
                <ul className="list-disc pl-5 mt-2">
                  {sqlEvents
                    .filter((e) => e.start_ts.startsWith(selectedDate))
                    .map((e) => (
                      <li key={e.id}>{e.title}</li>
                    ))}
                </ul>
              </div>
            )}
          </>
        )}
      </Layout>
    </>
  );
}
CalendarPage.auth = true;
