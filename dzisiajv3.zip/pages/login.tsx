"use client";

import { useEffect } from "react";
import { useRouter } from "next/router";
import { useSession, useSupabaseClient } from "@supabase/auth-helpers-react";
import Head from "next/head";

export default function LoginPage() {
  const session = useSession();
  const supabase = useSupabaseClient();
  const router = useRouter();

  const nextPath =
    typeof router.query.next === "string" ? router.query.next : "/tasks";

  useEffect(() => {
    if (session) {
      router.replace(nextPath);
    }
  }, [session, nextPath, router]);

  if (session === undefined) {
    return <div>Ładowanie…</div>;
  }

  async function signInWithGoogle() {
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: `${window.location.origin}${nextPath}`,
      },
    });
    if (error) console.error("Błąd logwania:", error.message);
  }

  return (
    <>
      <Head>
        <title>Logowanie – Dzisiaj v3</title>
      </Head>
      <div className="min-h-screen flex flex-col justify-center items-center text-center bg-gray-50 p-4">
        <div className="bg-card p-6 rounded-xl shadow mb-6">
          <h1 className="text-3xl text-primary font-bold mb-6">Dzisiaj v3</h1>
          <p className="mb-6">Zaloguj się, aby skorzystać z aplikacji</p>
          <div className="flex justify-center">
            <button
              onClick={signInWithGoogle}
              className="px-6 py-2 bg-red-500 hover:bg-red-600 text-white rounded-full transition"
            >
              Zaloguj
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
