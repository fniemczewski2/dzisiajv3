import "../styles/globals.css";
import type { AppProps } from "next/app";
import dynamic from "next/dynamic";
import { SessionContextProvider } from "@supabase/auth-helpers-react";
import { getBrowserSupabaseClient } from "../lib/supabaseClient";

// dynamic import, bo AuthGuard jest client‐only
const AuthGuard = dynamic(() => import("../components/AuthGuard"), {
  ssr: false,
});

function MyApp({ Component, pageProps }: AppProps) {
  // jeśli na komponencie jest flag (TasksPage.auth = true),
  // to owijamy go w AuthGuard. W przeciwnym razie renderujemy go „czysto”.
  const needsAuth = (Component as any).auth as boolean;

  return (
    <SessionContextProvider supabaseClient={getBrowserSupabaseClient()}>
      {needsAuth ? (
        <AuthGuard>
          <Component {...pageProps} />
        </AuthGuard>
      ) : (
        <Component {...pageProps} />
      )}
    </SessionContextProvider>
  );
}

export default MyApp;
