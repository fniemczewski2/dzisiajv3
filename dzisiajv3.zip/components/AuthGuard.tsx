// components/AuthGuard.tsx
"use client";

import { useSession } from "@supabase/auth-helpers-react";
import { useRouter } from "next/router";
import { useEffect, ReactNode } from "react";

export default function AuthGuard({ children }: { children: ReactNode }) {
  const session = useSession();
  const router = useRouter();

  useEffect(() => {
    if (session === null) {
      // jeśli nie ma sesji, zapamiętaj, skąd przyszliśmy, i rzuć do logowania
      const next = encodeURIComponent(router.asPath);
      router.replace(`/login?next=${next}`);
    }
  }, [session, router]);

  if (session === undefined) {
    return <div>Ładowanie…</div>;
  }

  return <>{children}</>;
}
