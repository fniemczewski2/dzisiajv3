import { createClient } from "@supabase/supabase-js";
import { createPagesBrowserClient } from "@supabase/auth-helpers-nextjs";
import type { SupabaseClient } from "@supabase/supabase-js";

// Browser-side client for use with Supabase Auth Helpers
let browserSupabase: SupabaseClient | null = null;
export function getBrowserSupabaseClient(): SupabaseClient {
  if (!browserSupabase) {
    browserSupabase = createPagesBrowserClient();
  }
  return browserSupabase;
}

// Direct Supabase client for standalone queries outside of auth-helpers context
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;
export const supabase: SupabaseClient = createClient(supabaseUrl, supabaseKey);
